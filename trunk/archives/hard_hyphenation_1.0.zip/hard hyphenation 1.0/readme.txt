Hiphenator v1.0
----------

Hyphenator is a javascript api that performs hyphenation on text in html pages.


The main features of Hyphenator: 

  - Called when page is loaded.
  - Accepts 2 arguments:
	- hyphenType: that may be
		'H' - for hard hyphenation using <wbr> tag (zero width space)
		'S' = for soft hyphenation using &shy; (inserts a hyphen in place where
		      it is situated in the text)
	- selector: that is needed in order to tell the api on which components to apply
	  the hyphenation algorithm.
  - Uses jQuery selectors for finding required components to process.


Use and configuration instructions:
  - Hyphenation is provided as 2 javascript files (normal and compressed).
  - You need jQuery library in order to use this api.
  - To initialize and run the script you should place on body tag onload attribute: 
	<body onload="Hyphenation.findAndFix('H', '.preview');">
  - Provide the type of the hyphenation you want : 'H' for <wbr>, 'S' for &shy;
  - Provide the selector that will be used from the api to find the components on which
    to apply the hyphenation algorithm. Selector may be any acceptable selector in jQuery.



This distribution contains the following files:

  hardhyphenation.js		- JavaScript file containing whole api
  hardhyphenation-min.js	- Compressed version of the file
  jquery-1.3.2.js		- The jQuery library
  test.html			- A simple test demo page
  readme.txt			- This file

---
End of document